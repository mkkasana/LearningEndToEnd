"""Auth API routes."""

from datetime import timedelta
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import HTMLResponse
from fastapi.security import OAuth2PasswordRequestForm

from app.api.deps import CurrentUser, SessionDep, get_current_active_admin
from app.core.config import settings
from app.core.exceptions import AuthenticationError, InactiveUserError
from app.schemas.auth import NewPassword, Token
from app.schemas.common import Message
from app.schemas.user import UserPublic
from app.services.auth_service import AuthService
from app.services.user_service import UserService
from app.utils import (
    generate_password_reset_token,
    generate_reset_password_email,
    send_email,
    verify_password_reset_token,
)
from app.utils.logging_decorator import log_route

router = APIRouter(tags=["login"])


@router.post("/login/access-token")
@log_route
def login_access_token(
    session: SessionDep, form_data: Annotated[OAuth2PasswordRequestForm, Depends()]
) -> Token:
    """
    OAuth2 compatible token login, get an access token for future requests
    """
    auth_service = AuthService(session)

    # Authenticate user
    user = auth_service.authenticate_user(
        email=form_data.username, password=form_data.password
    )

    if not user:
        raise AuthenticationError("Incorrect email or password")

    if not auth_service.is_user_active(user):
        raise InactiveUserError()

    # Create access token
    access_token_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    return auth_service.create_access_token_for_user(user, access_token_expires)


@router.post("/login/test-token", response_model=UserPublic)
@log_route
def test_token(current_user: CurrentUser) -> Any:
    """
    Test access token
    """
    return current_user


@router.post("/password-recovery/{email}")
@log_route
def recover_password(email: str, session: SessionDep) -> Message:
    """
    Password Recovery
    """
    user_service = UserService(session)
    user = user_service.get_user_by_email(email)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="The user with this email does not exist in the system.",
        )

    password_reset_token = generate_password_reset_token(email=email)
    email_data = generate_reset_password_email(
        email_to=user.email, email=email, token=password_reset_token
    )
    send_email(
        email_to=user.email,
        subject=email_data.subject,
        html_content=email_data.html_content,
    )
    return Message(message="Password recovery email sent")


@router.post("/reset-password/")
@log_route
def reset_password(session: SessionDep, body: NewPassword) -> Message:
    """
    Reset password
    """
    email = verify_password_reset_token(token=body.token)
    if not email:
        raise HTTPException(status_code=400, detail="Invalid token")

    user_service = UserService(session)
    user = user_service.get_user_by_email(email)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="The user with this email does not exist in the system.",
        )
    elif not user.is_active:
        raise InactiveUserError()

    user_service.update_password(user, body.new_password)
    return Message(message="Password updated successfully")


@router.post(
    "/password-recovery-html-content/{email}",
    dependencies=[Depends(get_current_active_admin)],
    response_class=HTMLResponse,
)
def recover_password_html_content(email: str, session: SessionDep) -> Any:
    """
    HTML Content for Password Recovery
    """
    user_service = UserService(session)
    user = user_service.get_user_by_email(email)

    if not user:
        raise HTTPException(
            status_code=404,
            detail="The user with this username does not exist in the system.",
        )

    password_reset_token = generate_password_reset_token(email=email)
    email_data = generate_reset_password_email(
        email_to=user.email, email=email, token=password_reset_token
    )

    return HTMLResponse(
        content=email_data.html_content, headers={"subject:": email_data.subject}
    )
