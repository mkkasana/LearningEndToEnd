"""Tests for application enums."""
