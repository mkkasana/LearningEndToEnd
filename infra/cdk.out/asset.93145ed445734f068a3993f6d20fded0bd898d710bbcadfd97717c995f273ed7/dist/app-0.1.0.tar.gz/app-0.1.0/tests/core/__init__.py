# Tests for core module
