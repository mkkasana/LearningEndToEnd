"""Relatives network service tests."""
