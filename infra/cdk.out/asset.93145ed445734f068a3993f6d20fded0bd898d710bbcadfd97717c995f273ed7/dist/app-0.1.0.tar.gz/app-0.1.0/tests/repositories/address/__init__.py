"""Address repository tests."""
