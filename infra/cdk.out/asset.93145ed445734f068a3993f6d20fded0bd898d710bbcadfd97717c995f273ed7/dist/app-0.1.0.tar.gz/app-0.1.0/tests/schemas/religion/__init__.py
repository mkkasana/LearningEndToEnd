"""Religion schema tests."""
