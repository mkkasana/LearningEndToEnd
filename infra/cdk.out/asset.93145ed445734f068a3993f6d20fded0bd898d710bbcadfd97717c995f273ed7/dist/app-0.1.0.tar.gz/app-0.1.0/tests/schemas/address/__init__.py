"""Address schema tests."""
