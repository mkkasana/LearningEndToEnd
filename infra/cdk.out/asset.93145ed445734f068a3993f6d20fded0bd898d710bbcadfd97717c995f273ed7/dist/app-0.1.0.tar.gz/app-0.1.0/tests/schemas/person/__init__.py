"""Person schema tests."""
